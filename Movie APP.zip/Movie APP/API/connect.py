import requests
import pprint
import abc

api_key = "bcf2e18973957288fc03e93374527204"

"""
Endpoint
GET/movie/{movie_id}
https://api.themoviedb.org/3/movie/550?api_key=bcf2e18973957288fc03e93374527204
"""
api_version = 3
api_base_url = f"https://api.themoviedb.org/{api_version}"
endpoint_path = f"/search/movie"
search_query = "Iron Man"
endpoint = f"{api_base_url}{endpoint_path}?api_key={api_key}&query={search_query}"
print(endpoint)

r = requests.get(endpoint)
if r.status_code in range(200, 299):
  data = r.json()
  results = data['results']
  if len(results) > 0:
     #print(results[0].keys())
     for result in results:
        movie = result['title']
        year = result['release_date']
        vote_average = result['vote_average']
        print(movie, year, vote_average) 

     






