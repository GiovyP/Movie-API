from tkinter import *
import requests
import json
import pprint

api_key = "bcf2e18973957288fc03e93374527204"

root = Tk()
root.title('MovieDB API')
root.geometry("800x550")

def searchLookup():
    
    try: 
        api_version = 3  
        api_base_url = f"https://api.themoviedb.org/{api_version}"
        endpoint_path = f"/search/movie" 
        search_query = search.get() 
        endpoint = f"{api_base_url}{endpoint_path}?api_key={api_key}&query={search_query}" 
    
        r = requests.get(endpoint)
        if r.status_code in range(200, 299):
            data = r.json()
            results = data['results']
            pprint.pprint(results)
            print_results1= ''
            print_results2= ''
            print_results3= ''
            if len(results) > 0:
                for result in results:

                    movie = result['title']
                    year = result['release_date']
                    vote_average = result['vote_average']

                    res1 = f" {movie} "
                    res2 = f" {year} "  
                    res3 = f" {vote_average}" 

                    print_results1 += str(res1) + "\n" 
                    print_results2 += str(res2) + "\n" 
                    print_results3 += str(res3) + "\n" 
                
        
        root.configure(background="#fdf6e3")
        
        queryLabel = Label(root, text=print_results1, font=("Times New Roman", 12),background="#fdf6e3")
        queryLabel.grid(row=8, column =0, columnspan=2)
        queryLabel = Label(root, text=print_results2, font=("Times New Roman", 12),background="#fdf6e3")
        queryLabel.grid(row=8, column =2)
        queryLabel = Label(root, text=print_results3, font=("Times New Roman", 12),background="#fdf6e3")
        queryLabel.grid(row=8, column =3, columnspan=2)

    except Exception as e:
        api = "Error"

search=Entry(root)
search.grid(row=0, column=2, padx=20)

searchButton = Button(root, text="Search Movie", command=searchLookup)
searchButton.grid(row=0, column=3, columnspan=2)

movie_name_label = Label(root, text="        Movie Title:     ", font=("Times New Roman", 20),background="#eee8d5")
movie_name_label.grid(row=6, column=1)
release_date_label = Label(root, text="           Release Date:     ", font=("Times New Roman", 20),background="#eee8d5")
release_date_label.grid(row=6, column=2)
average_label = Label(root, text="          Vote Average:     ", font=("Times New Roman", 20),background="#eee8d5")
average_label.grid(row=6, column=3)


root.mainloop() 